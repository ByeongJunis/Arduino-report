var github = require('../');
var url = github(require('./package.json'));
console.log(url);
